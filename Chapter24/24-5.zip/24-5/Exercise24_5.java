class Exercise24_5 {
	public static void main(String[] args) {
		
		GenericQueue<String> list1 = new GenericQueue<String>();    
		list1.enqueue("Tupac");
		System.out.println("The world before 1996: " + list1);
		list1.dequeue();
		System.out.println("The world after 1996: " + list1);
	}
}